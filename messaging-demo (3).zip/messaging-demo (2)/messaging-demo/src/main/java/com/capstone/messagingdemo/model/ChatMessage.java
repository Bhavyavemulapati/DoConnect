package com.capstone.messagingdemo.model;

public class ChatMessage {
    
    private String fromLogin;
    private String message;
    

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    public String getFromLogin() {
        return fromLogin;
    }

    public void setFromLogin(String fromlogin) {
        this.fromLogin = fromLogin;
    }
    @Override
    public String toString() {
        return "MessageModel{" +
                "message='" + message + '\'' +
                ", fromLogin='" + fromLogin + '\'' +
                '}';
    }


}