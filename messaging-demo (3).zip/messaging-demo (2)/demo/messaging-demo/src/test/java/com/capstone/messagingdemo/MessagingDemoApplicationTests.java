package com.capstone.messagingdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessagingDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
